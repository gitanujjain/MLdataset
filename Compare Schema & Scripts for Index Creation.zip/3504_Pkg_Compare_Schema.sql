SET SERVEROUTPUT ON

/* Package to Validate Compare Schema */

CREATE OR REPLACE PACKAGE pkg_compare_schema
AS

	PROCEDURE usp_insert_metadata
		 (
		    p_product_code IN VARCHAR2
		           ,p_area IN VARCHAR2
		        ,p_version IN VARCHAR2
		     	  ,p_owner IN VARCHAR2
         
	 	 );
	PROCEDURE usp_ref_cons_compare
                (
                    p_product_code IN VARCHAR2
		           ,p_area IN VARCHAR2
   		        ,p_version IN VARCHAR2
 		          ,p_owner IN VARCHAR2
                );
	PROCEDURE usp_schema_verify
        	 (
		    p_product_code IN VARCHAR2
		           ,p_area IN VARCHAR2
		        ,p_version IN VARCHAR2
		     	  ,p_owner IN VARCHAR2
         
	 	 );
	PROCEDURE usp_compr_schma_prim_indx
        	 (
		    p_product_code IN VARCHAR2
		           ,p_area IN VARCHAR2
		        ,p_version IN VARCHAR2
		     	  ,p_owner IN VARCHAR2
			 ,P_TBLSPC IN VARCHAR2
         
	 	 );
	PROCEDURE usp_compare_schm_cre_prim_cons
		 (
		    p_product_code IN VARCHAR2
		           ,p_area IN VARCHAR2
		        ,p_version IN VARCHAR2
		     	  ,p_owner IN VARCHAR2
         
	 	 );
	PROCEDURE usp_cre_scripts_alt_ref_index 
	    (
		    p_product_code IN VARCHAR2
	               ,p_area IN VARCHAR2
	            ,p_version IN VARCHAR2
	     	      ,p_owner IN VARCHAR2
		 ,P_TBLSPC IN VARCHAR2
        );
	PROCEDURE usp_cre_scrip_ref_const
	   (
			p_product_code IN VARCHAR2
		           ,p_area IN VARCHAR2
   		        ,p_version IN VARCHAR2
 		          ,p_owner IN VARCHAR2
       );

END pkg_compare_schema;
/

/* Package Body for Validating Compare_Schema */

CREATE OR REPLACE PACKAGE BODY pkg_compare_schema   
AS
/*******************************************/
/* Procedure to update ref_cons details	   */
/*******************************************/
PROCEDURE usp_ref_cons_compare (
                             p_product_code IN VARCHAR2
		                    ,p_area IN VARCHAR2
				    ,p_version IN VARCHAR2
 		     	            ,p_owner IN VARCHAR2
                            )
IS
CURSOR  C1 IS 
             SELECT 
                      a.object_name
                     ,a.subobject_name
                     ,a.constraint_type
                     ,b.r_owner
                     ,b.r_constraint_name ref_cons
               FROM   compare_schema a
                     ,all_constraints b
              WHERE  a.constraint_type='R' 
                AND  a.subobject_type='CONSTRAINTS' 
                AND  a.object_type='TABLE' 
                AND  a.column_name is NULL 
                AND  a.subobject_name=b.constraint_name
                AND  a.object_name=b.table_name
                AND  a.owner=UPPER(p_owner)
		AND a.product_code=UPPER(p_product_code)
                AND a.area=UPPER(p_area)
                AND a.version=upper(p_version)
              ORDER  BY a.object_name
                    ,a.subobject_name
                    ,a.column_position;

CURSOR C2(obj_name VARCHAR2,subobj_name VARCHAR2) IS
             SELECT  
                     a.object_name
                    ,a.subobject_name
                    ,a.column_name
                    ,a.column_position 
               FROM compare_schema a
              WHERE a.constraint_type='R' 
                AND a.subobject_type='CONSTRAINTS COLUMNS' 
                AND a.object_type='TABLE' 
                AND a.column_name is NOT NULL
                AND a.object_name=obj_name
                AND a.subobject_name=subobj_name
                AND a.product_code=UPPER(p_product_code)
                AND a.area=UPPER(p_area)
                AND a.version=upper(p_version)
                AND a.owner=upper(p_owner);
 
cURSOR c3 (ref_constraint vARCHAR2,col_pos NUMBER) IS
             SELECT 
                    table_name
                   ,column_name
                   ,position 
               FROM all_cons_columns
              WHERE constraint_name=ref_constraint
                AND position=col_pos
                AND owner=UPPER(p_owner);
BEGIN
	FOR i IN C1
	LOOP
		FOR j IN c2(i.object_name,i.subobject_name)
                LOOP
                       FOR k IN c3(i.ref_cons,j.column_position)
                       LOOP
              UPDATE compare_schema 
                 SET ref_table=k.table_name
                    ,ref_column=k.column_name 
               WHERE object_name=j.object_name 
                 AND subobject_name=j.subobject_name
                 AND column_name=j.column_name 
                 AND column_position=j.column_position 
                 AND Constraint_type='R' 
                 AND column_name is not NULL;
 
 /*  DBMS_OUTPUT.PUT_LINE(  j.object_name
                        ||'|'
                        ||j.subobject_name
                        ||'|'
                        ||j.column_name
                        ||'|'
                        ||j.column_position
                        ||'|'
                        ||k.table_name
                        ||'|'
                        ||k.column_name
                       ); */


                        END LOOP;
                END LOOP;
        END LOOP;
        COMMIT;
END;

/***************************************************/
/* PROCEDURE To Validate Objects 		   */
/***************************************************/

PROCEDURE usp_schema_verify
        	 (
		    p_product_code IN VARCHAR2
		           ,p_area IN VARCHAR2
		        ,p_version IN VARCHAR2
		     	  ,p_owner IN VARCHAR2
         
	 	 )
IS

---- Compare Table (Not exist in USERS)

CURSOR c1 IS  	
	SELECT  a.*
	    FROM  compare_schema a 
         WHERE  NOT EXISTS (SELECT  1 FROM  all_tables b 
                             WHERE b.table_name = a.object_name 
                               AND b.owner=UPPER(p_owner)
                           ) 
           AND  a.product_code=UPPER(p_product_code) 
           AND  a.area=UPPER(p_area)
           AND  a.version=p_version
           AND a.object_type='TABLE' 
           AND a.subobject_type is NULL;

---- Compare COLUMNS (Not exist in USERS)

CURSOR c2 IS  
	SELECT  a.*
          FROM  compare_schema a 
         WHERE  not exists (SELECT  1 FROM all_tab_columns b 
                             WHERE  a.object_name = b.table_name 
                               AND  a.column_name = b.column_name
                               AND  a.column_data_type = b.data_type 
                               AND  a.column_data_length = b.data_length 
                               AND b.owner = UPPER(p_owner)
                           ) 
          AND a.product_code = UPPER(p_product_code) 
          AND a.area = UPPER(p_area) 
          AND a.version = p_version
          AND a.object_type = 'TABLE' 
          AND subobject_type = 'COLUMN'
        ORDER BY object_name;



---- Compare INDEX (Not exist in USERS)

CURSOR c3 IS  
       SELECT  a.*
         FROM  compare_schema a  
        WHERE  not exists (SELECT  1 FROM  all_indexes b 
                    	    WHERE b.index_name = a.subobject_name 
                              AND b.table_name = a.object_name 
                              AND b.owner = UPPER(p_owner)
                          ) 
          AND  a.product_code = UPPER(p_product_code) 
          AND  a.area = UPPER(p_area)
          AND  a.version = p_version
          AND  a.subobject_type = 'INDEX';



---- Compare INDEX COLUMNS (Not exist in USERS)

CURSOR c4 IS  
       SELECT  a.*
         FROM  compare_schema a 
        WHERE  not exists (SELECT 1 FROM all_ind_columns b 
                            WHERE a.object_name = b.table_name 
                              AND a.column_name = b.column_name
                              AND a.subobject_name = b.index_name 
                              AND a.column_position = b.column_position 
                              AND b.index_owner = UPPER(p_owner) 
                          )
          AND  a.product_code = UPPER(p_product_code) 
          AND  a.area = UPPER(p_area) 
          AND  a.version = p_version 
          AND  a.object_type ='TABLE' 
          AND  subobject_type = 'INDEX COLUMNS'
        ORDER  BY object_name;



---- Compare CONSTRAINTS (Not exist in USERS)

CURSOR c5 IS  
       SELECT  a.*
         FROM  compare_schema a
        WHERE  object_type = 'TABLE' 
          AND  subobject_type = 'CONSTRAINTS'
          AND  not exists (SELECT  1 
                             FROM all_constraints b 
                            WHERE a.object_name = b.table_name 
                              AND a.subobject_name = constraint_name 
                              AND b.owner = UPPER(p_owner)
                          ) 
          AND  a.product_code = UPPER(p_product_code) 
          AND  a.area = UPPER(p_area) 
          AND  a.version = p_version 
          AND  constraint_type not in ('C')
          AND  column_name is null;
		
		


---- Compare CONSTRAINTS COLUMNS (Not exist in USERS)

CURSOR c6 IS  
       SELECT a.*
     	 FROM  compare_schema a
        WHERE  NOT EXISTS ( SELECT 1 FROM all_constraints b 
                             WHERE a.object_name = b.table_name 
                               AND a.subobject_name = constraint_name 
                               AND b.owner = UPPER(p_owner)
                          )
          AND  a.product_code = UPPER(p_product_code) 
          AND  a.area = UPPER(p_area) 
          AND  a.version = p_version 
          AND  object_type = 'TABLE' 
          AND  subobject_type = 'CONSTRAINTS COLUMNS' 
          AND  constraint_type not in ('C')
          AND  column_name is not null;




---- Compare VIEW,sequences,etc.... (Not exist in USERS)

CURSOR c7 IS  
       SELECT  a.*
         FROM  compare_schema a  
        WHERE  NOT EXISTS (SELECT 1 FROM  all_objects b 
                            WHERE b.object_name = a.object_name 
                              AND a.object_type = b.object_type 
                              AND b.owner = UPPER(p_owner)
                          )
          AND  a.product_code = UPPER(p_product_code) 
          AND  a.area = UPPER(p_area) 
          AND  a.version = p_version
          AND  a.object_type IN ( 'VIEW'
                                 ,'SEQUENCE'
                                 ,'FUNCTION'
                                 ,'PROCEDURE'
                                 ,'PACKAGE'
                                 ,'PACKAGE BODY'
                                 ,'TRIGGER'
                                 ,'SYNONYM'
                                 ,'TYPE'
                                 );

i compare_schema%rowtype;
BEGIN
        
        --##############################TABLES############################################
	
	BEGIN --FOR C1 

	DBMS_OUTPUT.new_line;
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.PUT_LINE(lpad('COMPARE_SCHEMA_TABLES',40,' '));
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.new_line;
	
        IF NOT c1%ISOPEN
		THEN
		  open c1;
		END IF;
		
		LOOP
		FETCH c1 into i;
		If c1%rowcount=0 THEN
			DBMS_OUTPUT.PUT_LINE('NO ERROR RECORDS IN COMPARE SCHEMA TABLES');
		 END If;
          EXIT WHEN C1%NOTFOUND;
		  IF C1%rowcount=1
		  THEN
		  DBMS_OUTPUT.PUT_LINE('OBJECT_NAME'||rpad(' ',20)||'OBJECT_TYPE'); 
		  DBMS_OUTPUT.PUT_LINE(rpad('-',11,'-')||rpad(' ',20)||rpad('-',11,'-'));
	      END IF;
          DBMS_OUTPUT.PUT_LINE(  rpad(i.object_name,30)
                               ||' '
                               ||rpad(i.object_type,30)
                              );
          END LOOP;
		  CLOSE C1;
		END;  

	--############################COLUMNS##############################################

	BEGIN --FOR C2 
    DBMS_OUTPUT.new_line;
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.PUT_LINE(lpad('COMPARE_SCHEMA_TABLES_COLUMNS',40,' '));
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.new_line;
	


         IF NOT c2%ISOPEN
		THEN
		  open c2;
		END IF;
		 
		LOOP
		FETCH C2 into i;
		If C2%rowcount=0 THEN
		    DBMS_OUTPUT.PUT_LINE('NO ERROR RECORDS IN COMPARE SCHEMA TABLES COLUMNS');
		 END If;
		 EXIT WHEN C2%NOTFOUND;
		IF C2%rowcount=1 THEN
		DBMS_OUTPUT.PUT_LINE('OBJECT_NAME'||rpad(' ',20)||'OBJECT_TYPE'||rpad(' ',5)||'SUBOBJECT_TYPE'||rpad(' ',2)||'COLUMN_NAME'||rpad(' ',21)||'COLUMN_DATA_TYPE'||rpad(' ',2)||'COLUMN_DATA_LENGTH'); 
		DBMS_OUTPUT.PUT_LINE(rpad('-',11,'-')||rpad(' ',20)||rpad('-',11,'-')||rpad(' ',5)||rpad('-',14,'-')||rpad(' ',2)||rpad('-',11,'-')||rpad(' ',21)||rpad('-',16,'-')||rpad(' ',2)||rpad('-',18,'-')); 
		END IF;
          EXIT WHEN C2%NOTFOUND;
          DBMS_OUTPUT.PUT_LINE(  rpad(i.object_name,30)
                               ||' '
                               ||rpad(i.object_type,15)
                               ||' '
                               ||rpad(i.subobject_type,15)
                               ||' '
                               ||rpad(i.column_name,31)
                               ||' '
                               ||rpad(i.column_data_type,17)
                               ||' '
                               ||i.column_data_length
                              );
   
          END LOOP;
	    CLOSE C2;
         
        END;

	--############################INDEXS##########################################
 
	BEGIN --FOR C3 

	DBMS_OUTPUT.new_line;
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.PUT_LINE(lpad('COMPARE_SCHEMA_INDEXES',40,' '));
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.new_line;
	

		IF NOT C3%ISOPEN
		THEN
		  OPEN C3;
		END IF;
          LOOP
		  FETCH C3 into i;
		  IF C3%ROWCOUNT = 0 THEN
		  DBMS_OUTPUT.PUT_LINE('NO ERROR RECORDS IN COMPARE SCHEMA INDEXES');
          END IF;
		  EXIT WHEN C3%NOTFOUND;
		  IF C3%ROWCOUNT = 1 THEN
		  DBMS_OUTPUT.PUT_LINE('OBJECT_NAME'||rpad(' ',20)||'SUBOBJECT_NAME'||rpad(' ',17)||'SUBOBJECT_TYPE'); 
		  DBMS_OUTPUT.PUT_LINE(rpad('-',11,'-')||rpad(' ',20)||rpad('-',14,'-')||rpad(' ',17)||rpad('-',14,'-'));
		  END IF;
          DBMS_OUTPUT.PUT_LINE(  rpad(i.object_name,30)
                               ||' '
                               ||rpad(i.subobject_Name,30)
                               ||' '
                               ||rpad(i.subobject_Type,15)
                              );
          END LOOP;
		  CLOSE C3; 
          
        END;

	--############################INDEXS COLUMNS##########################################
 
	BEGIN --FOR C4  
	
	DBMS_OUTPUT.new_line;
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.PUT_LINE(lpad('COMPARE_SCHEMA_INDEX_COLUMNS',40,' '));
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.new_line;
	


          IF NOT C4%ISOPEN
		  THEN
			OPEN C4;
		  END IF;
          LOOP
		  FETCH C4 into i;
		  IF C4%ROWCOUNT = 0 THEN
		  DBMS_OUTPUT.PUT_LINE('NO ERROR RECORDS IN COMPARE SCHEMA INDEX COLUMNS');
          END IF;
		  EXIT WHEN C4%NOTFOUND;
		  IF C4%ROWCOUNT = 1 THEN
		  DBMS_OUTPUT.PUT_LINE('OBJECT_NAME'||rpad(' ',20)||'OBJECT_TYPE'||rpad(' ',5)||'SUBOBJECT_TYPE'||rpad(' ',2)||'SUBOBJECT_NAME'||rpad(' ',17)||'COLUMN_NAME'||rpad(' ',21)||'COLUMN_POSITION'); 
		  DBMS_OUTPUT.PUT_LINE(rpad('-',11,'-')||rpad(' ',20)||rpad('-',11,'-')||rpad(' ',5)||rpad('-',14,'-')||rpad(' ',2)||rpad('-',14,'-')||rpad(' ',17)||rpad('-',11,'-')||rpad(' ',21)||rpad('-',15,'-'));
          END IF;
          DBMS_OUTPUT.PUT_LINE(  rpad(i.OBJECT_NAME,30)
                               ||' '
                               ||rpad(i.OBJECT_TYPE,15)
                               ||' '
                               ||rpad(i.SUBOBJECT_TYPE,15)
                               ||' '
                               ||rpad(i.SUBOBJECT_NAME,30)
                               ||' '
                               ||rpad(i.COLUMN_NAME,31)
                               ||' '
                               ||i.COLUMN_POSITION
                              );
   
          END LOOP;
		CLOSE C4;
          
        END;

	--############################CONSTRAINTS##########################################
 
	BEGIN --FOR C5  	

	DBMS_OUTPUT.new_line;
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.PUT_LINE(lpad('COMPARE_SCHEMA_CONSTRAINTS',40,' '));
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.new_line;

	IF NOT C5%ISOPEN
		  THEN
			OPEN C5;
		  END IF;
          LOOP
		  FETCH C5 into i;
		  IF C5%ROWCOUNT = 0 THEN
			DBMS_OUTPUT.PUT_LINE('NO ERROR RECORDS IN COMPARE SCHEMA CONSTRAINTS');
		   END IF;
		   EXIT WHEN C5%NOTFOUND;
		   IF C5%ROWCOUNT = 1 THEN
		  DBMS_OUTPUT.PUT_LINE('OBJECT_NAME'||rpad(' ',20)||'OBJECT_TYPE'||rpad(' ',5)||'SUBOBJECT_TYPE'||rpad(' ',2)||'SUBOBJECT_NAME'||rpad(' ',17)||'CONSTRAINT_TYPE'||rpad(' ',2)||'STATUS'); 
		  DBMS_OUTPUT.PUT_LINE(rpad('-',11,'-')||rpad(' ',20)||rpad('-',11,'-')||rpad(' ',5)||rpad('-',14,'-')||rpad(' ',2)||rpad('-',14,'-')||rpad(' ',17)||rpad('-',15,'-')||rpad(' ',2)||rpad('-',6,'-'));
          END IF;
          DBMS_OUTPUT.PUT_LINE(  rpad(i.OBJECT_NAME,30)
                               ||' '
                               ||rpad(i.OBJECT_TYPE,15)
                               ||' '
                               ||rpad(i.SUBOBJECT_TYPE,15)
                               ||' '
                               ||rpad(i.SUBOBJECT_NAME,30)
                               ||' '
                               ||rpad(i.CONSTRAINT_TYPE,16)
                               ||' '
                               ||i.STATUS
                              );
   
          END LOOP;
	      CLOSE C5;
        
        END;

	--############################CONSTRAINT COLUMNS####################################


	BEGIN --FOR C6  	
    DBMS_OUTPUT.new_line;
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.PUT_LINE(lpad('COMPARE_SCHEMA_CONSTRAINT_COLUMNS',40,' '));
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.new_line;
	
         IF NOT C6%ISOPEN
		  THEN
			OPEN C6;
		  END IF;
          LOOP
		  FETCH C6 into i;
		  IF C6%ROWCOUNT = 0 THEN
			DBMS_OUTPUT.PUT_LINE('NO ERROR RECORDS IN COMPARE SCHEMA CONSTRAINT COLUMNS');
          END IF;
		  
		  EXIT WHEN C6%NOTFOUND;
		  IF C6%ROWCOUNT = 1 THEN
		  DBMS_OUTPUT.PUT_LINE('OBJECT_NAME'||rpad(' ',20)||'OBJECT_TYPE'||rpad(' ',5)||'SUBOBJECT_TYPE'||rpad(' ',8)||'SUBOBJECT_NAME'||rpad(' ',17)||'CONSTRAINT_TYPE'||rpad(' ',2)||'COLUMN_NAME'||rpad(' ',20)||'COLUMN_POSITION'); 
		  DBMS_OUTPUT.PUT_LINE(rpad('-',11,'-')||rpad(' ',20)||rpad('-',11,'-')||rpad(' ',5)||rpad('-',14,'-')||rpad(' ',8)||rpad('-',14,'-')||rpad(' ',17)||rpad('-',15,'-')||rpad(' ',2)||rpad('-',11,'-')||rpad(' ',20)||rpad('-',15,'-'));
          END IF;
          DBMS_OUTPUT.PUT_LINE(  RPAD(i.OBJECT_NAME,30)
                               ||' '
                               ||RPAD(i.OBJECT_TYPE,15)
                               ||' '
                               ||RPAD(i.SUBOBJECT_TYPE,21)
                               ||' '
                               ||RPAD(i.SUBOBJECT_NAME,30)
                               ||' '
                               ||RPAD(i.CONSTRAINT_TYPE,17)
                               ||' '
                               ||RPAD(i.COLUMN_NAME,30)
                               ||' '
                               ||i.COLUMN_POSITION
                              );
   
          END LOOP;
		  CLOSE C6;
	  
          
        END;

        --##############################OTHER OBJECTS############################################
	
	BEGIN --FOR C7 
    DBMS_OUTPUT.new_line;
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.PUT_LINE(lpad('COMPARE_SCHEMA_OTHER_OBJECTS',40,' '));
	DBMS_OUTPUT.PUT_LINE(rpad('*',150,'*'));
	DBMS_OUTPUT.new_line;
	
	


          IF NOT C7%ISOPEN
		  THEN
			OPEN C7;
		  END IF;
          LOOP
		  FETCH C7 into i;
		  IF C7%ROWCOUNT = 0 THEN
			DBMS_OUTPUT.PUT_LINE('NO ERROR RECORDS IN COMPARE SCHEMA OTHER_OBJ/- LIKE VIEW,SEQ/-,FN/-...');
          END IF;
		  
		  EXIT WHEN C7%NOTFOUND;
		  IF C7%ROWCOUNT = 1 THEN
		  DBMS_OUTPUT.PUT_LINE('OBJECT_NAME'||rpad(' ',20)||'OBJECT_TYPE'||rpad(' ',5)||'STATUS'); 
		  DBMS_OUTPUT.PUT_LINE(rpad('-',11,'-')||rpad(' ',20)||rpad('-',11,'-')||rpad(' ',5)||rpad('-',6,'-'));
	      END IF;
		  
          DBMS_OUTPUT.PUT_LINE(  rpad(i.OBJECT_NAME,30)
                               ||' '
                               ||rpad(i.OBJECT_TYPE,15)
                               ||' '
                               ||i.STATUS 
                              );
          END LOOP;
	    CLOSE C7;
          
        END;

EXCEPTION 

WHEN OTHERS THEN
	--RAISE_APPLICATION_ERROR(-20198,'INVALID TRY');
	dbms_output.put_line('The error is : '||sqlerrm);
END;

/**************************************************************************/
/* Procedure to create missing primary index Script                       */
/**************************************************************************/
PROCEDURE usp_compr_schma_prim_indx
        	 (
		    p_product_code IN VARCHAR2
		           ,p_area IN VARCHAR2
		        ,p_version IN VARCHAR2
		     	  ,p_owner IN VARCHAR2
			 ,P_TBLSPC IN VARCHAR2
         
	 	 )
IS
CURSOR C1 IS 
	    SELECT 
                    a.object_name
                   ,a.object_type
                   ,subobject_type
                   ,subobject_name
              FROM  compare_schema a 
             WHERE  NOT EXISTS ( SELECT  1 FROM all_ind_columns b 
                                  WHERE  a.object_name = b.table_name 
                                    AND  a.column_name = b.column_name
                                    AND  a.subobject_name = b.index_name 
                                    AND  a.column_position = b.column_position 
                                    AND  b.index_owner = upper(p_owner)
                               )
	      AND  a.product_code = upper(p_Product_code) 
              AND  a.area = upper(p_area)
              AND  a.version = p_version
              AND  a.object_type = 'TABLE' 
              AND  subobject_type = 'INDEX COLUMNS' 
              AND  a.subobject_name like 'PK_%'
            GROUP  BY object_name
                     ,object_type
                     ,subobject_type
                     ,subobject_name
            ORDER  BY object_name
                     ,object_type
                     ,subobject_type
                     ,subobject_name;

CURSOR C2(    obj_name varchar2
              ,obj_type varchar2
           ,subobj_type varchar2
           ,subobj_name varchar2
          ) IS
	      SELECT a.object_name
                    ,a.object_type
                    ,subobject_type
                    ,subobject_name
                    ,column_name
                    ,column_position
               FROM  compare_schema a
              WHERE  a.object_type = obj_type 
                AND  a.object_name = obj_name 
                AND  a.subobject_type = subobj_type
                AND  a.subobject_name = subobj_name 
                AND  column_name is not NULL
              ORDER  BY a.object_name
                       ,a.subobject_name
                       ,a.column_position;

querystr Varchar2(3000) := NULL;
     cnt Number         := 0;
    cnt1 Number         := 0;
ind_name Varchar2(30);


BEGIN
FOR i IN C1 LOOP

	DBMS_OUTPUT.PUT_LINE('spool create_primary_index.sql');
/* CHeck unique index present */
	SELECT  count(1) 
          INTO  cnt 
          FROM  all_indexes 
         WHERE  table_name = i.object_name 
           AND  uniqueness = 'UNIQUE' 
           AND  owner = UPPER(p_owner);
  
       IF cnt > 0 THEN

           SELECT  index_name 
             INTO  ind_name 
             FROM  all_indexes 
            WHERE  table_name = i.object_name 
              AND  uniqueness = 'UNIQUE' 
              AND  owner = UPPER(p_owner);

        /* Check for columns present or not */
           SELECT  count(1) 
             INTO  cnt1
             FROM  compare_schema a 
            WHERE  a.object_name = i.object_name 
              AND  a.uniqueness = 'UNIQUE'
              AND  ( column_name
                    ,column_position
                   ) IN ( SELECT  column_name
                                 ,column_position 
                            FROM  all_ind_columns
                           WHERE  index_owner = UPPER(p_owner) 
                             AND  index_name = ind_name
                         );
                                

		IF cnt1 > 0 THEN
                
               /* Rename the Primary Key Index */
   
                     querystr :=  'ALTER INDEX '
 		                          ||ind_name
								  ||' RENAME TO '
                                  ||i.subobject_name
                                  ||';';
                ELSE
                     DBMS_OUTPUT.PUT_LINE (  'The index: '
                                           ||ind_name
                                           ||' does not match for table: '
                                           ||i.object_name
                                           ||' original index: '
                                           ||i.subobject_name
                                          ); 
                END IF;
       ELSE
  
         FOR j IN C2 ( i.object_name
                      ,i.object_type
                      ,i.subobject_type
                      ,i.subobject_name
                      )                 LOOP

                IF (j.column_position = 1) THEN
                 
                       querystr :=  'CREATE UNIQUE INDEX '
                                  ||p_owner
                                  ||'.'
                                  ||j.subobject_name
                                  ||' ON '
                                  ||p_owner
                                  ||'.'
                                  ||j.object_name
                                  ||' ('
                                  ||j.column_name;
                ELSE
               
                      querystr :=   querystr
                                  ||','
                                  ||j.column_name;
                END IF;
         END LOOP;
                      IF P_TBLSPC IS NULL THEN 
					  
							querystr :=   querystr
										||');';
					  ELSE 
							querystr :=   querystr
										||') '
										||'TABLESPACE '
										||P_TBLSPC
										||'; ';
					  END IF;
END IF;					  
DBMS_OUTPUT.PUT_LINE(querystr);
END LOOP;
DBMS_OUTPUT.PUT_LINE('spool off');
END;

--***********************************************
--THIS procedure for create primary constraint
--***********************************************

PROCEDURE usp_compare_schm_cre_prim_cons
		 (
		    p_product_code IN VARCHAR2
		           ,p_area IN VARCHAR2
		        ,p_version IN VARCHAR2
		     	  ,p_owner IN VARCHAR2
         
	 	 )
IS
	
              cnt Number          := 0;
         querystr varchar2(2000)  := NULL;
        querystr1 varchar2(2000)  := NULL;
 max_col_position Number          := 0;
         obj_name varchar2(30);
      subobj_name varchar2(30);
        cons_name varchar2(30);

CURSOR Cur_Constraints IS
			SELECT  
		                        object_name
                               ,object_type
                               ,subobject_type
                               ,subobject_name
                               ,constraint_type
                          FROM  compare_schema a
                         WHERE   NOT EXISTS  ( SELECT  1 FROM  all_constraints b 
                                               WHERE  a.object_name = b.table_name 
                                                 AND  a.subobject_name = b.constraint_name 
                                                 AND  b.owner = UPPER(p_owner)
                                            )
                           AND a.product_code = upper(p_Product_code) 
                           AND a.area = UPPER(p_area) 
                           AND a.version = p_version
                           AND object_type = 'TABLE' 
                           AND subobject_type = 'CONSTRAINTS' 
                           AND constraint_type IN ('P')       
                         GROUP BY object_name
                                 ,object_type
                                 ,subobject_type
                                 ,subobject_name
                                 ,constraint_type
                         ORDER BY object_name
                                 ,subobject_name;

CURSOR Cur_Cons_Columns(
                             obj_name varchar2
                            ,obj_type varchar2
                         ,subobj_name varchar2
                         ,subobj_type varchar2
                           ,cons_type varchar2
                       ) IS 
                          SELECT subobject_name
                                ,column_name
                                ,column_position
                                ,ref_table
                                ,ref_column 
                            FROM compare_schema 
                           WHERE product_code = upper(p_Product_code) 
                             AND area = UPPER(p_area) 
                             AND version = p_version
                             AND object_name = obj_name 
                             AND object_type = obj_type 
                             AND subobject_name = subobj_name 
                             AND subobject_type = 'CONSTRAINTS COLUMNS'
                           ORDER BY subobject_name
                                ,column_position;

BEGIN

dbms_output.put_line('spool cre_primary_cons.log');


FOR Rec_Constraints IN CUR_CONSTRAINTS LOOP
        

	BEGIN
        	SELECT 
                       a.object_name
                      ,a.subobject_name
                      ,b.constraint_name
                      ,count(1) 
                  INTO obj_name
                      ,subobj_name
                      ,cons_name
                      ,cnt 
                  FROM compare_schema a
                      ,all_constraints b
                 WHERE a.object_name = b.table_name 
                   AND b.constraint_type = 'P' 
                   AND a.constraint_type = b.constraint_type 
                   AND a.column_name is NULL
                   AND a.subobject_name <> b.constraint_name 
                   AND a.object_name = Rec_Constraints.object_name 
                   AND b.owner = UPPER(p_owner)
                 GROUP BY a.object_name
                         ,a.subobject_name
                         ,b.constraint_name;

              querystr :=  'ALTER TABLE '
                         		||p_owner
		                        ||'.'
                		        ||obj_name
                         ||' RENAME CONSTRAINT '
                         		||cons_name
                         ||' TO '
					||subobj_name
                         ||';';

       EXCEPTION
         WHEN NO_DATA_FOUND THEN
         cnt:=0;
       END;
            IF Cnt = 0 THEN 
                 
		 FOR Rec_columns IN Cur_Cons_Columns (
                                                       Rec_Constraints.object_name
                                                      ,Rec_Constraints.object_type
                                                      ,Rec_Constraints.subobject_name
                                                      ,Rec_Constraints.subobject_type
                                                      ,Rec_Constraints.constraint_type
                                                     ) LOOP
        		SELECT max(column_position) 
                          INTO max_col_position 
                          FROM compare_schema
                         WHERE product_code = upper(p_Product_code) 
                           AND area = UPPER(p_area) 
                           AND version = p_version
                           AND object_name = Rec_Constraints.object_name 
                           AND object_type = Rec_Constraints.object_type 
                           AND subobject_name = Rec_Constraints.subobject_name
                           AND subobject_type = Rec_Constraints.subobject_type 
                           AND column_name is not null;

           			IF Rec_Columns.column_position = 1 THEN
                		
					querystr :=  'ALTER TABLE '
                                                   		   ||p_owner
		                                                   ||'.'
                		                                   ||Rec_constraints.object_name
                                                   ||' ADD CONSTRAINT '
								   ||Rec_constraints.subobject_name
                                                   ||' PRIMARY KEY ('
                                                                   ||Rec_columns.column_name;
                		ELSE               
						querystr :=  querystr
                                                           ||','
                                                           ||rec_columns.column_name;
                               END IF;
                  END LOOP;
            END IF;
		DBMS_OUTPUT.PUT_LINE(querystr||');');
END LOOP;
DBMS_OUTPUT.PUT_LINE('spool off');
END;

--************************************
--this procedure for alter ref_index
--************************************

PROCEDURE usp_cre_scripts_alt_ref_index (
															p_product_code IN VARCHAR2
	                                                               ,p_area IN VARCHAR2
	                                                            ,p_version IN VARCHAR2
	     	                                                      ,p_owner IN VARCHAR2
													     ,P_TBLSPC IN VARCHAR2
                                                          )
IS 														   

max_col_position Number := 0;
rename_flg char(1);

CURSOR C1 IS 
		   SELECT  a.object_name
		          ,a.object_type
				  ,subobject_type
				  ,subobject_name
             FROM  compare_schema a 
			WHERE  NOT EXISTS ( SELECT 1 FROM  all_ind_columns b 
			                     WHERE   a.object_name = b.table_name 
								   AND   a.column_name = b.column_name
                                   AND   a.subobject_name = b.index_name 
								   AND   a.column_position = b.column_position 
								   AND   b.index_owner = UPPER(p_owner) 
							   )
              AND  a.product_code = upper(p_Product_code) 
			  AND  a.area = UPPER(p_area) 
			  AND  a.version = p_version
              AND  a.object_type = 'TABLE' 
			  AND  subobject_type = 'INDEX COLUMNS' 
			  AND  a.subobject_name NOT LIKE 'PK_%'
            GROUP  BY object_name
			      ,object_type
				  ,subobject_type
				  ,subobject_name
            ORDER  BY object_name
			      ,object_type
				  ,subobject_type
				  ,subobject_name;

CURSOR C2(    obj_name varchar2
             ,obj_type varchar2
		  ,subobj_type varchar2
		  ,subobj_name varchar2) IS 
		                          SELECT  a.object_name
								         ,a.object_type
										 ,subobject_type
										 ,subobject_name
										 ,column_name
										 ,column_position
                                    FROM  compare_schema a
								   WHERE  a.object_type = obj_type 
								     AND  a.object_name = obj_name 
									 AND  a.subobject_type = subobj_type
                                     AND  a.subobject_name = subobj_name
                                   ORDER  BY a.object_name
								            ,a.subobject_name
											,a.column_position;

cnt NUmber := 0;
querystr Varchar2(3000) := NULL;

CURSOR Cur_Same_index(     obj_name varchar2
                       ,subObj_name varchar2
					   ,maxposition Integer) IS
                                              SELECT DISTINCT index_name 
											    FROM all_ind_columns 
											   WHERE index_name IN (SELECT a.index_name 
											                          FROM all_ind_columns a
																	      ,compare_schema b 
																     WHERE a.index_name != b.subobject_name
                                                                       AND a.column_name = b.column_name
																	   AND a.column_position = b.column_position
																	   AND a.table_name = obj_name
																	   AND b.subobject_name = subobj_name
																	   AND b.object_name = obj_name
																	   AND a.table_owner = UPPER(p_owner)
																	   AND b.product_code = upper(p_Product_code) 
																	   AND b.area = UPPER(p_area) 
																	   AND b.version = p_version
																	   AND b.object_type = 'TABLE' 
																	   AND b.subobject_type = 'INDEX COLUMNS'
                                                                     GROUP BY a.index_name 
																	HAVING MAX(a.column_position) = maxposition);

BEGIN
DBMS_OUTPUT.PUT_LINE('spool cre_alter_index.log');
FOR i IN C1 LOOP
Rename_flg := 'N';

	SELECT  MAX(column_position) 
	  INTO  max_col_position 
	  FROM  compare_schema
     WHERE  product_code = upper(p_Product_code) 
	   AND  area = UPPER(p_area) 
	   AND  version = p_version
       AND  object_name = i.object_name 
	   AND  object_type = i.object_type 
	   AND  subobject_name = i.subobject_name
       AND  subobject_type = 'INDEX COLUMNS' ;
 
 /* Check whether index need an Rename */
       FOR INDX_MAX_RENAME IN Cur_Same_index(     i.object_name
	                                          ,i.subobject_name
											  ,max_col_position) LOOP
                 
				 querystr :=  'ALTER INDEX '
				            ||INDX_MAX_RENAME.index_name
							||' RENAME TO '
							||i.subobject_name
							||';';
                 DBMS_OUTPUT.PUT_LINE(querystr);
                 Rename_flg := 'Y';
       END LOOP;
     
  /* If Index not present Create the new index */
    IF Rename_flg = 'N' THEN
        
		FOR j IN C2 (       i.object_name
		                   ,i.object_type
						,i.subobject_type
						,i.subobject_name ) LOOP
           
    	   IF (j.column_position = 1) THEN
              querystr :=  'CREATE INDEX '
			             ||p_owner
						 ||'.'
						 ||j.subobject_name
						 ||' on '
						 ||p_owner
						 ||'.'
						 ||j.object_name
						 ||' ('
						 ||j.column_name;
           ELSE
            querystr :=  querystr
			           ||','
					   ||j.column_name;
          END IF;
        END LOOP;
    END IF;
        /* Concatenate the Full Query and add Tablespace */
    IF Rename_flg = 'N' THEN
		IF P_TBLSPC IS NULL THEN 
			querystr :=  querystr
	                   ||') ;';
            DBMS_OUTPUT.PUT_LINE(querystr);
		ELSE 
			querystr :=  querystr
 	                   ||') TABLESPACE '
                       ||P_TBLSPC
					   ||'; ';
            DBMS_OUTPUT.PUT_LINE(querystr);
		END IF;
    END IF;

END LOOP;
DBMS_OUTPUT.PUT_LINE('spool off');
END;

--********************************************************
--this procedure for generate scripts_reference constrains
--******************************************************** 

PROCEDURE usp_cre_scrip_ref_const(
															 p_product_code IN VARCHAR2
		                                                            ,p_area IN VARCHAR2
   		                                                         ,p_version IN VARCHAR2
 		     	                                                   ,p_owner IN VARCHAR2
                                                            )
 IS
cnt Number:=0;
cons_name varchar2(30);
querystr varchar2(2000) := NULL;
querystr1 varchar2(2000):= NULL;
ref_table1 varchar2(30);
max_col_position Number:=0;
rename_flg char(1);
CURSOR cur_Constraints IS 
                        SELECT  object_name
						       ,object_type
							   ,subobject_type
							   ,subobject_name
							   ,constraint_type
                          FROM  compare_schema a
						 WHERE  NOT EXISTS ( SELECT 1 FROM  all_constraints b 
						                             WHERE  a.object_name = b.table_name 
													   AND  a.subobject_name = constraint_name 
                                                       AND  b.owner = UPPER(p_owner)
									       )
                           AND  a.product_code = upper(p_Product_code) 
						   AND  a.area = UPPER(p_area) 
						   AND  a.version = p_version
                           AND  object_type = 'TABLE' 
						   AND  subobject_type = 'CONSTRAINTS' 
						   AND  constraint_type IN ('R') 
						   AND  column_name IS NULL
                         GROUP  BY object_name
						          ,object_type
								  ,subobject_type
								  ,subobject_name
								  ,constraint_type
                         ORDER  BY object_name
						          ,subobject_name;


CURSOR cur_Cons_Columns (    obj_name varchar2
                            ,obj_type varchar2
						 ,subobj_name varchar2
						 ,subobj_type varchar2
						   ,cons_type varchar2 )IS 
						                         SELECT  subobject_name
												        ,column_name
														,column_position
														,ref_table
														,ref_column 
												   FROM  compare_schema 
												  WHERE  product_code = upper(p_Product_code)
                                                    AND  area = UPPER(p_area) 
													AND  version = p_version
                                                    AND  object_name = obj_name 
													AND  object_type = obj_type 
													AND  subobject_name = subobj_name 
												  --AND subobject_type=subobj_type 
													AND constraint_type IN ('R') 
													AND subobject_type = 'CONSTRAINTS COLUMNS'
												  ORDER BY subobject_name
												          ,column_position;

CURSOR cur_Same_Constraint (  obj_name varchar2
                          ,subObj_name varchar2
						  ,maxposition Integer ) IS
                                                  SELECT  DISTINCT constraint_name 
												    FROM  all_cons_columns 
												   WHERE  constraint_name IN ( SELECT a.constraint_name 
												                                 FROM all_cons_columns a
																				     ,compare_schema b 
																			    WHERE a.constraint_name != b.subobject_name
																				  AND a.column_name = b.column_name
																				  AND a.position = b.column_position
																				  AND a.table_name = obj_name
																				  AND b.subobject_name = subobj_name
																				  AND b.object_name = obj_name
																				  AND a.owner = UPPER(p_owner)
																				  AND b.product_code = upper(p_Product_code) 
																				  AND b.area = UPPER(p_area) 
																				  AND b.version = p_version
																				  AND b.object_type = 'TABLE' 
																				  AND b.subobject_type = 'CONSTRAINTS COLUMNS'
																				GROUP BY a.constraint_name 
																			   HAVING MAX(a.position) = maxposition);	

BEGIN
DBMS_OUTPUT.PUT_LINE('spool cre_ref_cons.log');
FOR Rec_Constraints IN CUR_CONSTRAINTS LOOP
Rename_flg := 'N';
/* Check for the max column position */
        SELECT  MAX( column_position ) 
		  INTO  max_col_position 
		  FROM  compare_schema
         WHERE  product_code = upper(p_Product_code) 
		   AND  area = UPPER(p_area) 
		   AND  version = p_version
           AND  object_name = Rec_Constraints.object_name 
		   AND  object_type = Rec_Constraints.object_type 
		   AND  subobject_name = Rec_Constraints.subobject_name
           AND  subobject_type = 'CONSTRAINTS COLUMNS' 
		   AND  column_name IS NOT NULL;

/* Check whether the constraint present with different name */
		   FOR cons_rename IN Cur_Same_Constraint ( rec_constraints.object_name
		                                           ,rec_constraints.subobject_name
												   ,max_col_position ) LOOP
				
				querystr :=  'ALTER TABLE '
				           ||Rec_Constraints.object_name
						   ||' RENAME CONSTRAINT  '
						   ||cons_rename.constraint_name
						   ||' TO '
						   ||Rec_constraints.subobject_name
						   ||';';
             Rename_flg := 'Y';
          END LOOP;
         
/* If constraints not Present Create Constraints Script */
      IF Rename_flg = 'N' THEN
       
    	FOR Rec_columns IN Cur_cons_columns (     Rec_Constraints.object_name
		                                         ,Rec_Constraints.object_type
											  ,Rec_Constraints.subobject_name
											  ,Rec_Constraints.subobject_type
											 ,Rec_Constraints.constraint_type ) LOOP
             
					IF Rec_Columns.column_position = 1 THEN
                
				          querystr :=  'ALTER TABLE '
						             ||p_owner
									 ||'.'
									 ||Rec_constraints.object_name
									 ||' ADD (CONSTRAINT '
									 ||Rec_constraints.subobject_name
									 ||' FOREIGN KEY ('
									 ||Rec_columns.column_name;
                         querystr1 := rec_columns.ref_column;
                   ELSE
                        IF Rec_Columns.column_position <= max_col_position THEN
                          querystr :=  querystr
						             ||','
									 ||rec_columns.column_name;
                         querystr1 :=  querystr1
						             ||','
									 ||rec_columns.ref_column;
                        END IF;
                   END IF;
       
   	       ref_table1 := Rec_columns.ref_table;
   	     END LOOP;
      END IF;
   
    IF Rename_flg = 'N' THEN
   
                         querystr :=  querystr
						            ||') REFERENCES '
									||ref_table1
									||' ('
									||querystr1
									||'));';
    END IF;
   DBMS_OUTPUT.PUT_LINE(querystr);

END LOOP;
   DBMS_OUTPUT.PUT_LINE('spool off');
END;

--*********************************
-- this procedure for compare_schema 
--*********************************
PROCEDURE usp_insert_metadata
	 (
	    p_product_code IN VARCHAR2
	           ,p_area IN VARCHAR2
	        ,p_version IN VARCHAR2
	     	  ,p_owner IN VARCHAR2
         
	 )	
IS
BEGIN

--**************************
-- this statement for table  
--**************************

		INSERT INTO compare_schema (
                                       product_code
                                      ,area
                                      ,version
                                      ,owner
                                      ,object_name
                                      ,object_type
                                      ,status
                                      )
                       SELECT
  		                       UPPER(p_product_code)
                                      ,UPPER(p_area) 
                                      ,p_version
                                      ,owner owner
                                      ,table_name object_name
                                      ,'TABLE' object_type
                                      ,status status
                         FROM all_tables 
                        WHERE owner = UPPER(p_owner);
           COMMIT;
DBMS_OUTPUT.PUT_LINE('No Tables.............' || SQL%ROWCOUNT);

--*********************************
-- this statement for table columns 
--*********************************

-- Removed Views Columns 
     		INSERT INTO compare_schema (
                                       product_code
                                      ,area
                                      ,version,owner
                                      ,object_name
                                      ,object_type
                                      ,subobject_owner
                                      ,subobject_type
                                      ,column_name
                                      ,column_data_type
                                      ,column_data_length
                                      ,column_data_precision
                                      ,column_data_scale
                                      ,column_nullable
                                      )
				  SELECT  
                                       UPPER(p_product_code)
                                      ,UPPER(p_area) 
                                      ,p_version
		                      ,col.owner owner
                                      ,col.table_name Object_nm 
				      ,'TABLE' object_type
 				      ,col.owner  subobj_onr
                                      ,'COLUMN' subobj_typ
                                      ,col.column_name col_nm
                                      ,col.data_type col_data_ty
                                      ,col.data_length c_data_ln
                                      ,col.data_precision 
                                      ,col.data_scale 
                                      ,col.nullable 
                         FROM all_tab_columns col 
                         JOIN all_objects obj
                           ON (col.table_name = obj.object_name          
                          AND col.owner=obj.owner)
                        WHERE obj.object_type <> 'VIEW' 
                          AND col.owner =UPPER(p_owner)
                        ORDER BY table_name,column_id;
         COMMIT;
DBMS_OUTPUT.PUT_LINE('No columns..........' || SQL%ROWCOUNT);
           

--************************
--this statement for Index 
--************************

	INSERT INTO  compare_schema (
                          product_code
                         ,area
                         ,version
                         ,owner
                         ,object_name
                         ,object_type
                         ,subobject_owner
                         ,subobject_type
                         ,subobject_name
                         ,uniqueness
                         ,status 
                                 ) 
            SELECT 
		          UPPER(p_product_code)
                         ,UPPER(p_area) 
                         ,p_version
                         ,owner owner
                         ,table_name object_name
                         ,table_type object_type
                         ,owner subobject_owner
                         ,'INDEX' subobject_type
                         ,index_name subobject_name
                         ,uniqueness uniqueness
                         ,status status
              FROM all_indexes 
             WHERE owner =UPPER(p_owner);
         COMMIT;
DBMS_OUTPUT.PUT_LINE('No index.............' || SQL%ROWCOUNT);

--*******************************
--this statement for Index columns 
--*******************************
		INSERT INTO compare_schema (
                           product_code
                          ,area
                          ,version
                          ,owner
                          ,object_name
                          ,object_type
                          ,subobject_owner
                          ,subobject_type
                          ,subobject_name
                          ,uniqueness
                          ,column_name
                          ,column_position
                          ,status
                                      )
               SELECT 
     			   UPPER(p_product_code)
                          ,UPPER(p_area) 
                          ,p_version
		          ,ind.owner owner
                          ,ind.table_name object_name
                          ,ind.table_type object_type
                          ,owner subobject_owner
                          ,'INDEX COLUMNS' subobject_type
                          ,ind.index_name subobject_name
                          ,ind.uniqueness uniqueness
                          ,col.column_name column_name
                          ,col.column_position column_position
                          ,ind.status status
                 FROM all_indexes ind 
                 JOIN all_ind_columns col
			   ON (ind.index_name=col.index_name 
                  AND ind.table_owner=col.table_owner)
                WHERE ind.owner = UPPER(p_owner)
			ORDER BY subobject_name;
	COMMIT;
DBMS_OUTPUT.PUT_LINE('No Index Columns......'||SQL%ROWCOUNT);
           
--****************************
--this statement for Constraints 
--****************************
		 INSERT INTO compare_schema (
                                        product_code
                                       ,area
                                       ,version
                                       ,owner
                                       ,object_name
                                       ,object_type
                                       ,subobject_type
                                       ,subobject_name
                                       ,constraint_type
                                       ,status
                                       )
                      SELECT  
		                             UPPER(p_product_code)
                                       ,UPPER(p_area) 
                                       ,p_version
	                               ,owner owner 
        		               ,table_name object_name
 		                       ,'TABLE' object_type
 		                       ,'CONSTRAINTS' subobj_ty
		                       ,constraint_name subobject_name
		                       ,constraint_type subobject_type	          
                                       ,status status
                        FROM all_constraints 
                       WHERE owner=UPPER(p_owner)
				  ORDER BY subobject_name;
           COMMIT;
DBMS_OUTPUT.PUT_LINE('No Constraints.......'||SQL%ROWCOUNT);

--**************************************
-- this statement for Constraints Columns 
--**************************************

		INSERT INTO compare_schema (
                        product_code
                       ,area
                       ,version
                       ,owner
                       ,object_name
                       ,object_type
                       ,subobject_type
                       ,subobject_name
                       ,constraint_type
                       ,column_name
                       ,column_position
                       ,status)
                SELECT  UPPER(p_product_code)
                       ,UPPER(p_area) 
                       ,p_version
                       ,owner owner
                       ,table_name object_name
                       ,'TABLE' object_type
                       ,'CONSTRAINTS COLUMNS' subobject_type
                       ,constraint_name subobject_name
                       ,constraint_type constraint_type
                       ,column_name column_name
                       ,position column_position
                       ,status status	   
                 FROM   all_constraints 
              NATURAL JOIN all_cons_columns
                WHERE owner = UPPER(p_owner)
                ORDER BY subobject_name;
 
         COMMIT;
DBMS_OUTPUT.PUT_LINE('No Constraint Columns....'||SQL%ROWCOUNT);

--******************************
-- this statement for Views 
--******************************

	INSERT INTO  compare_schema (
		        product_code
                       ,area
                       ,version
                       ,owner
                       ,object_name
                       ,object_type
                       ,status
                                 )
          SELECT
                        UPPER(p_product_code)
                       ,UPPER(p_area) 
                       ,p_version
		       ,owner owner
                       ,object_name
                       ,object_type
                       ,status
             FROM all_objects 
            WHERE object_type = 'VIEW' 
              AND owner=UPPER(p_owner)
            ORDER BY object_name;
DBMS_OUTPUT.PUT_LINE('No Views..............' || sql%rowcount);
COMMIT;

--******************************
-- this statement for  SEQUENCES 
--******************************

	INSERT INTO  compare_schema (
                      product_code
                     ,area
                     ,version
                     ,owner
                     ,object_name
                     ,object_type
                     ,status
                                 )
          SELECT
                      UPPER(p_product_code)
                     ,UPPER(p_area) 
                     ,p_version
                     ,owner owner
                     ,object_name
                     ,object_type
                     ,status
            FROM all_objects 
           WHERE object_type = 'SEQUENCE' 
             AND owner=UPPER(p_owner)
           ORDER BY object_name;
DBMS_OUTPUT.PUT_LINE('No Sequences..........' || sql%rowcount);
COMMIT;


--******************************
-- this statement for FUNCTIONS 
--******************************
		INSERT INTO compare_schema (
                      product_code
                     ,area
                     ,version
                     ,owner
                     ,object_name
                     ,object_type
                     ,status
                                      )
               SELECT
    		      UPPER(p_product_code)
                     ,UPPER(p_area) 
                     ,p_version
                     ,owner owner
                     ,object_name
                     ,object_type
                     ,status
                 FROM all_objects 
                WHERE object_type = 'FUNCTION' 
                  AND owner=UPPER(p_owner)
                ORDER BY object_name;
DBMS_OUTPUT.PUT_LINE('No Functions...........' || sql%rowcount);
COMMIT;

--******************************
--this statement for PROCEDURES 
--******************************

		INSERT INTO compare_schema (
                      product_code
                     ,area
                     ,version
                     ,owner
                     ,object_name
                     ,object_type
                     ,status
                                      )
                SELECT
		      UPPER(p_product_code)
                     ,UPPER(p_area) 
                     ,p_version                
                     ,owner owner
                     ,object_name
                     ,object_type
                     ,status
                 FROM all_objects 
                WHERE object_type = 'PROCEDURE' 
                  AND owner=UPPER(p_owner)
                ORDER BY object_name;

DBMS_OUTPUT.PUT_LINE('No Procedures.........' || sql%rowcount);
COMMIT;

--****************************
--this statement for PACKAGES 
--****************************
		INSERT INTO compare_schema (
                      product_code
                     ,area
                     ,version
                     ,owner
                     ,object_name
                     ,object_type
                     ,status
                                      )
               SELECT
		      UPPER(p_product_code)
                     ,UPPER(p_area) 
                     ,p_version                
                     ,owner owner
                     ,object_name
                     ,object_type
                     ,status
                 FROM all_objects 
                WHERE object_type = 'PACKAGE' 
                  AND owner=UPPER(p_owner)
                ORDER BY object_name;
DBMS_OUTPUT.PUT_LINE('No Package...........' || sql%rowcount);
COMMIT;

--*********************************
--this statement for PACKAGE BODIES 
--*********************************
		INSERT INTO compare_schema (
                      product_code
                     ,area
                     ,version
                     ,owner
                     ,object_name
                     ,object_type
                     ,status
                                      )
               SELECT 
		      UPPER(p_product_code)
                     ,UPPER(p_area) 
                     ,p_version                
                     ,owner owner
                     ,object_name
                     ,object_type
                     ,status
                 FROM all_objects 
                WHERE object_type = 'PACKAGE BODY' 
                  AND owner=UPPER(p_owner)
                ORDER BY object_name;
DBMS_OUTPUT.PUT_LINE('No Package Bodies.....'||sql%rowcount);
COMMIT;
--**********************************
--this statement for TRIGGERS 
--**********************************
		INSERT INTO compare_schema (
                      product_code
                     ,area
                     ,version
                     ,owner
                     ,object_name
                     ,object_type
                     ,status
                                      )
               SELECT
		      UPPER(p_product_code)
                     ,UPPER(p_area) 
                     ,p_version                
                     ,owner owner
                     ,object_name
                     ,object_type
                     ,status
                 FROM all_objects 
			WHERE object_type = 'TRIGGER' 
                  AND owner=UPPER(p_owner)
                ORDER BY object_name;
DBMS_OUTPUT.PUT_LINE('No Triggers...........' || sql%rowcount);
COMMIT;

--********************************
--this statement for SYNONYMS 
--********************************
		INSERT INTO  compare_schema (
                      product_code
                     ,area
                     ,version
                     ,owner
                     ,object_name
                     ,object_type
                     ,status
                                       )
               SELECT 
                      UPPER(p_product_code)
                     ,UPPER(p_area) 
                     ,p_version                
                     ,owner owner
                     ,object_name
                     ,object_type
                     ,status
                FROM all_objects 
 		     WHERE object_type = 'SYNONYM'  
                  AND owner=UPPER(p_owner)
                ORDER BY object_name;
DBMS_OUTPUT.PUT_LINE('No Synonym........' || sql%rowcount);
COMMIT;

--******************************
--this statement for TYPES 
--******************************
		INSERT INTO  compare_schema (
                      product_code
                     ,area
                     ,version
                     ,owner
                     ,object_name
                     ,object_type
                     ,status
                                       )
		     SELECT 
                      UPPER(p_product_code)
                     ,UPPER(p_area) 
                     ,p_version                
                     ,owner owner
                     ,object_name
                     ,object_type
                     ,status
                 FROM all_objects 
                WHERE object_type = 'TYPE'  
                  AND owner=UPPER(p_owner)
                ORDER BY object_name;
DBMS_OUTPUT.PUT_LINE ('No Type..............' || sql%rowcount);
COMMIT;

usp_ref_cons_compare(
                         p_product_code 
		                ,p_area 
   		                ,p_version 
 		     	        ,p_owner
                               );
				   
END ;
END pkg_compare_schema;

/

-------------------------------------------------------------------------------------------------------------------------------------
/* END OF FILE */
-------------------------------------------------------------------------------------------------------------------------------------


