drop table Compare_Schema;

CREATE TABLE Compare_Schema
(
	Product_Code         VARCHAR2(30) NULL ,
	Area                 VARCHAR2(20) NULL ,
	Version              VARCHAR2(10) NULL ,
	Owner                VARCHAR2(30) NULL ,
	Object_Name          VARCHAR2(128) NULL ,
	Object_Type          VARCHAR2(20) NULL ,
	Subobject_Owner      VARCHAR2(30) NULL ,
	Subobject_Name       VARCHAR2(30) NULL ,
	Subobject_Type       VARCHAR2(20) NULL ,
	Uniqueness           VARCHAR2(9) NULL ,
	Constraint_Name      VARCHAR2(30) NULL ,
	Constraint_Type      VARCHAR2(1) NULL ,
	Column_Name          VARCHAR2(30) NULL ,
	Column_Position      NUMBER NULL ,
	Column_Data_Type     VARCHAR2(106) NULL ,
	Column_Data_Length   NUMBER NULL ,
	Column_Data_Precision NUMBER NULL ,
	Column_Data_Scale    NUMBER NULL ,
	Column_Nullable      VARCHAR2(1) NULL ,
	Status               VARCHAR2(10) NULL ,
	Ref_Table            VARCHAR2(30) NULL ,
	Ref_Column           VARCHAR2(30) NULL 
);


